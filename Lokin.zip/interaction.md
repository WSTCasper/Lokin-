# Lokin App Interaction Design

## Core Philosophy
"Show up, lock in, level up" - A streak-based motivation app that rewards consistency and engagement through cosmic-themed gamification.

## User Flow & Interactions

### 1. Authentication Flow
- **Pi SDK Integration**: Users must authenticate via Pi Network to save progress
- **Guest Mode**: Non-authenticated users can browse UI but cannot save data
- **Login/Logout**: Clear authentication state management with Pi.authenticate

### 2. Home Screen Interactions
- **Daily Check-In Button**: Central pulsing CTA that triggers streak progression
- **Streak Display**: Large glowing number showing current streak with animated ring
- **Grace Tokens**: Visual indicators (2 icons) showing available grace tokens
- **Best Streak**: Display of personal record
- **Next Unlock**: Progress indicator for next rank/tier
- **Wallet Access**: Icon/button to open slide-up rewards panel

### 3. Check-In Feedback System
- **Success States**: 
  - "Locked in" - Normal daily check-in
  - "Grace used" - Check-in using grace token after missed day
  - "Streak reset" - When streak is broken and no grace available
- **Visual Feedback**: Animated confirmations with cosmic particle effects

### 4. Challenges System
- **Daily Challenges**: 2-3 rotating challenges (e.g., perfect check-in, time-in-app)
- **Weekly Challenges**: 2 weekly challenges including consistency goals
- **Progress Tracking**: Animated progress bars showing completion status
- **Point Rewards**: Challenge completion awards points with celebration animations

### 5. Wallet/Rewards Panel (Slide-up)
- **Total Points**: Current point balance display
- **Breakdown**: Simple categorization (daily/weekly/bonus points)
- **Cosmetic Previews**: Locked/unlocked visual rewards
- **Coming Soon**: Rewards system placeholder

### 6. Rank/Prestige System
- **Tier Progression**: Rookie → Grinder → Locked → Elite → Legend
- **Badge Display**: Visual rank indicators on profile and leaderboards
- **Next Unlock**: Progress tracking for next tier advancement

### 7. Leaderboard Interactions
- **Filter Controls**: All-Time/Weekly/Daily segment switching
- **User Highlighting**: Current user row highlighted with distinct styling
- **Movement Indicators**: "+X spots today" animations for position changes
- **Competitor Focus**: Highlight nearest competitor above current user

### 8. Data Persistence
- **User Storage**: Streak, best streak, last check-in date, grace usage
- **Monthly Reset**: Grace tokens reset to 2 on 1st of each month
- **Challenge State**: Track progress across daily/weekly challenges
- **Leaderboard Stats**: Points, rank, and positioning data

## Interaction Patterns
- **Touch-First**: All interactions optimized for mobile touch
- **Immediate Feedback**: Every action provides instant visual/audio response
- **Progressive Disclosure**: Information revealed contextually to avoid overwhelm
- **Gamification Loops**: Clear cause-and-effect relationships for user actions
- **Social Proof**: Leaderboard integration for competitive motivation

## Accessibility Considerations
- **High Contrast**: Neon elements on dark background for visibility
- **Clear Hierarchy**: Visual weight guides user attention
- **Touch Targets**: Minimum 44px touch areas for all interactive elements
- **Loading States**: Clear feedback during async operations