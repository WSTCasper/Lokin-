# Lokin App Project Outline

## File Structure
```
/mnt/okcomputer/output/
├── index.html              # Main app entry point (Home screen)
├── leaderboard.html        # Leaderboard screen
├── main.js                # Core application logic
├── resources/             # Static assets folder
│   ├── logo.png          # Generated cosmic logo
│   ├── hero-bg.jpg       # Cosmic background image
│   ├── rank-badges/      # Rank tier badge images
│   └── particles/        # Particle effect assets
├── interaction.md         # Interaction design document
├── design.md             # Design style guide
└── outline.md            # This project outline
```

## Component Architecture

### Core Components

#### 1. PiAuthManager (main.js)
- **Purpose**: Handle Pi Network SDK authentication
- **Functions**:
  - `initializePiSDK()` - Load and initialize Pi SDK
  - `authenticateUser()` - Handle login/logout flow
  - `getUserData()` - Fetch authenticated user info
  - `checkAuthStatus()` - Verify authentication state
- **Data**: User session, authentication tokens

#### 2. StreakTracker (main.js)
- **Purpose**: Core streak management system
- **Functions**:
  - `checkIn()` - Process daily check-in
  - `calculateStreak()` - Compute current streak
  - `useGraceToken()` - Handle grace token usage
  - `resetStreak()` - Reset streak on missed day
- **Data**: Current streak, best streak, last check-in date, grace tokens

#### 3. ChallengeManager (main.js)
- **Purpose**: Daily and weekly challenge system
- **Functions**:
  - `generateDailyChallenges()` - Create 2-3 daily challenges
  - `generateWeeklyChallenges()` - Create 2 weekly challenges
  - `updateProgress()` - Track challenge completion
  - `awardPoints()` - Grant points for completion
- **Data**: Challenge list, progress tracking, point totals

#### 4. RankSystem (main.js)
- **Purpose**: User ranking and prestige system
- **Functions**:
  - `calculateRank()` - Determine user tier based on streak/points
  - `getNextRankProgress()` - Show advancement requirements
  - `getRankBadge()` - Return rank visual assets
- **Data**: Rank tiers, progression requirements, badge assets

#### 5. LeaderboardEngine (main.js)
- **Purpose**: Leaderboard data management
- **Functions**:
  - `getLeaderboardData()` - Fetch ranked user data
  - `filterByTimeframe()` - Apply All-Time/Weekly/Daily filters
  - `getUserPosition()` - Find current user's rank
  - `calculateMovement()` - Determine position changes
- **Data**: User rankings, statistics, movement history

### UI Components

#### 1. HomeScreen (index.html)
- **Sections**:
  - Cosmic background with particle effects
  - Streak ring display (large centered number)
  - Best streak indicator
  - Grace token status (2 icons)
  - Next unlock progress
  - Daily check-in button (with pulse animation)
  - Quick stats overview
- **Interactions**: Check-in button, wallet access, navigation

#### 2. WalletPanel (index.html - slide-up)
- **Sections**:
  - Total points display
  - Points breakdown (daily/weekly/bonus)
  - Cosmetic reward previews
  - "Rewards coming soon" placeholder
- **Interactions**: Swipe to open/close, point history

#### 3. ChallengesPanel (index.html)
- **Sections**:
  - Daily challenges list (2-3 items)
  - Weekly challenges list (2 items)
  - Progress bars for each challenge
  - Completion animations
- **Interactions**: Challenge details, progress updates

#### 4. LeaderboardScreen (leaderboard.html)
- **Sections**:
  - Filter controls (All-Time/Weekly/Daily)
  - Ranked user list
  - Current user highlighting
  - Movement indicators
  - Nearest competitor focus
- **Interactions**: Filter switching, user profile access

### Animation Components

#### 1. CosmicBackground (main.js)
- **Effects**: 
  - Animated star field using p5.js
  - Shader-based aurora effects
  - Subtle parallax movement
- **Performance**: GPU-accelerated, optimized for mobile

#### 2. StreakRing (main.js)
- **Animations**:
  - Pulsing glow effect using CSS animations
  - Progress ring with animated stroke
  - Particle burst on check-in completion
- **Libraries**: Anime.js for smooth transitions

#### 3. CheckInButton (main.js)
- **Animations**:
  - Subtle scale pulse using Anime.js
  - Ripple effect on tap
  - Color transition on state change
- **Feedback**: Visual + haptic feedback

### Data Management

#### 1. LocalStorageManager (main.js)
- **Purpose**: Client-side data persistence
- **Functions**:
  - `saveUserData()` - Store user progress
  - `loadUserData()` - Retrieve saved data
  - `clearUserData()` - Reset all progress
  - `exportData()` - Backup user data
- **Storage**: Browser localStorage with encryption

#### 2. MockDataGenerator (main.js)
- **Purpose**: Generate sample data for development
- **Functions**:
  - `generateLeaderboardData()` - Create ranked users
  - `generateChallengeData()` - Sample challenges
  - `generateRankData()` - Tier progression examples
- **Usage**: Development and testing only

## Page Structure

### index.html - Main App
```html
<!DOCTYPE html>
<html>
<head>
  <!-- Meta tags, title, CSS links -->
  <!-- Core libraries CDN links -->
</head>
<body>
  <!-- Cosmic background container -->
  <div id="cosmic-background"></div>
  
  <!-- Main app container -->
  <div id="app">
    <!-- Header with logo and auth status -->
    <header class="app-header">
      <img src="resources/logo.png" alt="Lokin" class="logo">
      <div class="auth-status">
        <button id="auth-button">Login with Pi</button>
      </div>
    </header>
    
    <!-- Home screen content -->
    <main class="home-screen">
      <!-- Streak ring display -->
      <div class="streak-container">
        <div class="streak-ring" id="streak-ring">
          <span class="streak-number" id="current-streak">0</span>
        </div>
        <div class="streak-info">
          <p>Best Streak: <span id="best-streak">0</span></p>
          <p>Grace Tokens: <span id="grace-tokens">2</span></p>
        </div>
      </div>
      
      <!-- Check-in button -->
      <button class="checkin-button" id="checkin-btn">
        <span>Daily Check-In</span>
      </button>
      
      <!-- Quick stats -->
      <div class="quick-stats">
        <div class="stat-item">
          <span class="stat-value" id="next-unlock">Rookie</span>
          <span class="stat-label">Next Rank</span>
        </div>
        <div class="stat-item">
          <span class="stat-value" id="total-points">0</span>
          <span class="stat-label">Total Points</span>
        </div>
      </div>
      
      <!-- Challenges panel -->
      <div class="challenges-panel">
        <h3>Today's Challenges</h3>
        <div class="challenge-list" id="daily-challenges"></div>
        <h3>Weekly Challenges</h3>
        <div class="challenge-list" id="weekly-challenges"></div>
      </div>
    </main>
    
    <!-- Wallet slide-up panel -->
    <div class="wallet-panel" id="wallet-panel">
      <div class="wallet-handle"></div>
      <div class="wallet-content">
        <!-- Wallet content -->
      </div>
    </div>
    
    <!-- Navigation -->
    <nav class="bottom-nav">
      <a href="index.html" class="nav-item active">Home</a>
      <a href="leaderboard.html" class="nav-item">Leaderboard</a>
    </nav>
  </div>
  
  <!-- JavaScript -->
  <script src="main.js"></script>
</body>
</html>
```

### leaderboard.html - Leaderboard Screen
```html
<!DOCTYPE html>
<html>
<head>
  <!-- Similar head structure -->
</head>
<body>
  <!-- Cosmic background -->
  <div id="cosmic-background"></div>
  
  <!-- Leaderboard content -->
  <main class="leaderboard-screen">
    <header class="page-header">
      <h1>Leaderboard</h1>
      <div class="filter-controls">
        <button class="filter-btn active" data-filter="all-time">All Time</button>
        <button class="filter-btn" data-filter="weekly">Weekly</button>
        <button class="filter-btn" data-filter="daily">Daily</button>
      </div>
    </header>
    
    <div class="leaderboard-list" id="leaderboard-list">
      <!-- Dynamic leaderboard content -->
    </div>
  </main>
  
  <!-- Navigation -->
  <nav class="bottom-nav">
    <a href="index.html" class="nav-item">Home</a>
    <a href="leaderboard.html" class="nav-item active">Leaderboard</a>
  </nav>
  
  <script src="main.js"></script>
</body>
</html>
```

## Development Phases

### Phase 1: Core Setup
1. Create HTML structure and CSS styling
2. Implement Pi SDK authentication
3. Set up basic streak tracking
4. Add cosmic background effects

### Phase 2: Main Features
1. Daily check-in functionality
2. Grace token system
3. Challenge generation and tracking
4. Points and ranking system

### Phase 3: Polish
1. Advanced animations and effects
2. Leaderboard implementation
3. Wallet panel with slide-up
4. Performance optimization

### Phase 4: Testing & Deployment
1. Cross-browser testing
2. Mobile responsiveness
3. Performance optimization
4. Final deployment

This architecture provides a scalable foundation for the Lokin app while maintaining clean separation of concerns and enabling future feature additions.