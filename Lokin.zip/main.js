// Lokin App - Main JavaScript File
// Core functionality for streak tracking, Pi authentication, and cosmic UI

class LokinApp {
    constructor() {
        this.currentUser = null;
        this.userData = {
            streak: 0,
            bestStreak: 0,
            lastCheckIn: null,
            graceTokens: 2,
            graceUsedThisMonth: 0,
            points: 0,
            rank: 'Rookie',
            challenges: {
                daily: [],
                weekly: []
            },
            leaderboardStats: {
                position: 0,
                movement: 0
            }
        };
        this.isAuthenticated = false;
        this.init();
    }

    async init() {
        await this.initializePiSDK();
        this.setupEventListeners();
        this.loadUserData();
        this.initializeCosmicBackground();
        this.updateUI();
        this.startAnimations();
    }

    // Pi SDK Authentication System
    async initializePiSDK() {
        try {
            // Initialize Pi SDK
            if (typeof Pi !== 'undefined') {
                await Pi.init({ version: '2.0' });
                console.log('Pi SDK initialized successfully');
            } else {
                console.warn('Pi SDK not available - running in demo mode');
                this.isAuthenticated = false;
                this.setupDemoMode();
            }
        } catch (error) {
            console.error('Failed to initialize Pi SDK:', error);
            this.setupDemoMode();
        }
    }

    async authenticateUser() {
        try {
            if (typeof Pi !== 'undefined') {
                const scopes = ['username', 'payments'];
                const authResult = await Pi.authenticate(scopes, this.onIncompletePaymentFound);
                
                if (authResult) {
                    this.currentUser = authResult.user;
                    this.isAuthenticated = true;
                    await this.loadUserData();
                    this.updateAuthUI();
                    return true;
                }
            }
        } catch (error) {
            console.error('Authentication failed:', error);
        }
        return false;
    }

    async logoutUser() {
        try {
            if (typeof Pi !== 'undefined') {
                await Pi.logout();
            }
            this.currentUser = null;
            this.isAuthenticated = false;
            this.clearLocalData();
            this.updateAuthUI();
        } catch (error) {
            console.error('Logout failed:', error);
        }
    }

    onIncompletePaymentFound(payment) {
        console.log('Incomplete payment found:', payment);
        // Handle incomplete payments
    }

    setupDemoMode() {
        // Create demo user for development
        this.currentUser = {
            uid: 'demo-user-123',
            username: 'DemoUser'
        };
        this.isAuthenticated = true;
        this.loadDemoData();
    }

    // Streak Management System
    async performCheckIn() {
        if (!this.isAuthenticated) {
            this.showNotification('Please login to save your progress', 'warning');
            return;
        }

        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const lastCheckIn = this.userData.lastCheckIn ? new Date(this.userData.lastCheckIn) : null;
        
        if (lastCheckIn) {
            const lastCheckInDate = new Date(lastCheckIn.getFullYear(), lastCheckIn.getMonth(), lastCheckIn.getDate());
            const daysDiff = Math.floor((today - lastCheckInDate) / (1000 * 60 * 60 * 24));

            if (daysDiff === 0) {
                this.showNotification('Already checked in today!', 'info');
                return;
            } else if (daysDiff === 1) {
                // Perfect check-in
                this.userData.streak++;
                this.userData.bestStreak = Math.max(this.userData.streak, this.userData.bestStreak);
                this.showNotification('Locked in! 🔥', 'success');
            } else if (daysDiff > 1) {
                // Streak broken - check for grace tokens
                if (this.userData.graceTokens > 0 && !this.userData.graceUsedRecently) {
                    this.userData.graceTokens--;
                    this.userData.graceUsedThisMonth++;
                    this.userData.streak++;
                    this.userData.graceUsedRecently = true;
                    this.showNotification('Grace used! Streak saved ⚡', 'warning');
                } else {
                    this.userData.streak = 1;
                    this.showNotification('Streak reset. New journey begins! 🚀', 'info');
                }
            }
        } else {
            // First check-in
            this.userData.streak = 1;
            this.showNotification('Welcome to Lokin! First check-in complete 🎯', 'success');
        }

        this.userData.lastCheckIn = now.toISOString();
        this.userData.points += 10; // Base points for check-in
        this.userData.graceUsedRecently = false;

        // Update challenges
        this.updateChallengeProgress('daily-checkin', 1);
        
        // Save and update UI
        await this.saveUserData();
        this.updateUI();
        this.triggerCheckInAnimation();
    }

    // Challenge System
    generateDailyChallenges() {
        const challenges = [
            { id: 'daily-checkin', title: 'Daily Check-In', description: 'Complete your daily check-in', target: 1, progress: 0, points: 10 },
            { id: 'perfect-day', title: 'Perfect Day', description: 'Check in without using grace', target: 1, progress: 0, points: 25 },
            { id: 'early-bird', title: 'Early Bird', description: 'Check in before 9 AM', target: 1, progress: 0, points: 15 }
        ];
        
        // Randomly select 2-3 challenges
        const selected = challenges.sort(() => 0.5 - Math.random()).slice(0, 2);
        return selected;
    }

    generateWeeklyChallenges() {
        return [
            { id: 'week-warrior', title: 'Week Warrior', description: 'Maintain streak for 7 days', target: 7, progress: 0, points: 100 },
            { id: 'consistency-king', title: 'Consistency King', description: 'Check in 5 days this week', target: 5, progress: 0, points: 75 }
        ];
    }

    updateChallengeProgress(challengeId, increment = 1) {
        // Update daily challenges
        this.userData.challenges.daily.forEach(challenge => {
            if (challenge.id === challengeId) {
                challenge.progress = Math.min(challenge.progress + increment, challenge.target);
                if (challenge.progress >= challenge.target) {
                    this.userData.points += challenge.points;
                    this.showNotification(`${challenge.title} completed! +${challenge.points} points`, 'success');
                }
            }
        });

        // Update weekly challenges
        this.userData.challenges.weekly.forEach(challenge => {
            if (challenge.id === challengeId) {
                challenge.progress = Math.min(challenge.progress + increment, challenge.target);
                if (challenge.progress >= challenge.target) {
                    this.userData.points += challenge.points;
                    this.showNotification(`${challenge.title} completed! +${challenge.points} points`, 'success');
                }
            }
        });
    }

    // Rank System
    calculateRank() {
        const streak = this.userData.streak;
        const points = this.userData.points;
        
        const ranks = [
            { name: 'Rookie', minStreak: 0, minPoints: 0, badge: '⭐' },
            { name: 'Grinder', minStreak: 7, minPoints: 100, badge: '🔥' },
            { name: 'Locked', minStreak: 30, minPoints: 500, badge: '🔒' },
            { name: 'Elite', minStreak: 100, minPoints: 2000, badge: '💎' },
            { name: 'Legend', minStreak: 365, minPoints: 10000, badge: '👑' }
        ];

        let currentRank = ranks[0];
        for (let rank of ranks) {
            if (streak >= rank.minStreak && points >= rank.minPoints) {
                currentRank = rank;
            }
        }

        this.userData.rank = currentRank.name;
        return currentRank;
    }

    getNextRankProgress() {
        const currentRank = this.calculateRank();
        const ranks = [
            { name: 'Rookie', minStreak: 0, minPoints: 0 },
            { name: 'Grinder', minStreak: 7, minPoints: 100 },
            { name: 'Locked', minStreak: 30, minPoints: 500 },
            { name: 'Elite', minStreak: 100, minPoints: 2000 },
            { name: 'Legend', minStreak: 365, minPoints: 10000 }
        ];

        const currentIndex = ranks.findIndex(r => r.name === currentRank.name);
        if (currentIndex < ranks.length - 1) {
            const nextRank = ranks[currentIndex + 1];
            const streakProgress = Math.min(this.userData.streak / nextRank.minStreak, 1) * 100;
            const pointsProgress = Math.min(this.userData.points / nextRank.minPoints, 1) * 100;
            
            return {
                nextRank: nextRank.name,
                streakProgress: Math.round(streakProgress),
                pointsProgress: Math.round(pointsProgress),
                streakNeeded: Math.max(0, nextRank.minStreak - this.userData.streak),
                pointsNeeded: Math.max(0, nextRank.minPoints - this.userData.points)
            };
        }
        
        return null;
    }

    // Leaderboard System
    generateLeaderboardData(timeframe = 'all-time') {
        // Mock data for demonstration
        const users = [
            { username: 'StarWalker', streak: 245, points: 8500, rank: 'Elite' },
            { username: 'CosmicGrinder', streak: 189, points: 7200, rank: 'Locked' },
            { username: 'NebulaSeeker', streak: 156, points: 6100, rank: 'Locked' },
            { username: 'VoidWalker', streak: 134, points: 5400, rank: 'Locked' },
            { username: 'QuantumLeap', streak: 98, points: 4200, rank: 'Grinder' },
            { username: 'StellarPilot', streak: 87, points: 3800, rank: 'Grinder' },
            { username: 'GravityWell', streak: 76, points: 3400, rank: 'Grinder' },
            { username: 'PhotonTrail', streak: 65, points: 2900, rank: 'Grinder' },
            { username: 'DarkMatter', streak: 54, points: 2400, rank: 'Grinder' },
            { username: 'SolarFlare', streak: 43, points: 1900, rank: 'Grinder' }
        ];

        // Add current user if authenticated
        if (this.isAuthenticated && this.currentUser) {
            const currentUserData = {
                username: this.currentUser.username || 'You',
                streak: this.userData.streak,
                points: this.userData.points,
                rank: this.userData.rank,
                isCurrentUser: true
            };
            users.push(currentUserData);
        }

        // Sort by streak (primary) and points (secondary)
        users.sort((a, b) => {
            if (b.streak !== a.streak) {
                return b.streak - a.streak;
            }
            return b.points - a.points;
        });

        // Add rank positions
        return users.map((user, index) => ({
            ...user,
            position: index + 1,
            movement: Math.floor(Math.random() * 5) - 2 // Random movement for demo
        }));
    }

    // Data Persistence
    async saveUserData() {
        if (!this.isAuthenticated || !this.currentUser) return;

        const dataToSave = {
            uid: this.currentUser.uid,
            username: this.currentUser.username,
            ...this.userData,
            lastSaved: new Date().toISOString()
        };

        try {
            localStorage.setItem(`lokin_user_${this.currentUser.uid}`, JSON.stringify(dataToSave));
            
            // Also save to Pi SDK if available
            if (typeof Pi !== 'undefined' && Pi.server) {
                await Pi.server.save(dataToSave);
            }
        } catch (error) {
            console.error('Failed to save user data:', error);
        }
    }

    async loadUserData() {
        if (!this.isAuthenticated || !this.currentUser) return;

        try {
            // Try to load from localStorage first
            const savedData = localStorage.getItem(`lokin_user_${this.currentUser.uid}`);
            
            if (savedData) {
                const parsed = JSON.parse(savedData);
                this.userData = { ...this.userData, ...parsed };
                
                // Check if grace tokens need monthly reset
                this.checkGraceTokenReset();
                
                // Generate challenges if needed
                if (this.userData.challenges.daily.length === 0) {
                    this.userData.challenges.daily = this.generateDailyChallenges();
                }
                if (this.userData.challenges.weekly.length === 0) {
                    this.userData.challenges.weekly = this.generateWeeklyChallenges();
                }
            } else {
                // First time user - initialize with demo data
                this.userData.challenges.daily = this.generateDailyChallenges();
                this.userData.challenges.weekly = this.generateWeeklyChallenges();
            }
        } catch (error) {
            console.error('Failed to load user data:', error);
        }
    }

    checkGraceTokenReset() {
        const now = new Date();
        const lastSave = this.userData.lastSaved ? new Date(this.userData.lastSaved) : null;
        
        if (lastSave && now.getMonth() !== lastSave.getMonth()) {
            // New month - reset grace tokens
            this.userData.graceTokens = 2;
            this.userData.graceUsedThisMonth = 0;
        }
    }

    clearLocalData() {
        if (this.currentUser) {
            localStorage.removeItem(`lokin_user_${this.currentUser.uid}`);
        }
    }

    loadDemoData() {
        // Demo data for development
        this.userData = {
            streak: 15,
            bestStreak: 23,
            lastCheckIn: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
            graceTokens: 2,
            graceUsedThisMonth: 0,
            points: 450,
            rank: 'Grinder',
            challenges: {
                daily: this.generateDailyChallenges(),
                weekly: this.generateWeeklyChallenges()
            }
        };
    }

    // UI Updates
    updateUI() {
        this.updateStreakDisplay();
        this.updateStatsDisplay();
        this.updateChallengesDisplay();
        this.updateRankDisplay();
    }

    updateStreakDisplay() {
        const streakElement = document.getElementById('current-streak');
        const bestStreakElement = document.getElementById('best-streak');
        const graceTokensElement = document.getElementById('grace-tokens');

        if (streakElement) streakElement.textContent = this.userData.streak;
        if (bestStreakElement) bestStreakElement.textContent = this.userData.bestStreak;
        if (graceTokensElement) graceTokensElement.textContent = this.userData.graceTokens;

        // Update streak ring animation
        this.updateStreakRing();
    }

    updateStreakRing() {
        const ring = document.querySelector('.streak-ring');
        if (!ring) return;

        // Add pulsing animation
        ring.style.animation = 'pulse 2s infinite';
        
        // Update progress ring if streak > 0
        if (this.userData.streak > 0) {
            const progress = Math.min(this.userData.streak / 30, 1); // Max progress at 30 days
            const circumference = 2 * Math.PI * 45; // radius = 45
            const offset = circumference - (progress * circumference);
            
            const progressRing = ring.querySelector('.progress-ring');
            if (progressRing) {
                progressRing.style.strokeDasharray = circumference;
                progressRing.style.strokeDashoffset = offset;
            }
        }
    }

    updateStatsDisplay() {
        const totalPointsElement = document.getElementById('total-points');
        const nextUnlockElement = document.getElementById('next-unlock');

        if (totalPointsElement) totalPointsElement.textContent = this.userData.points;
        
        if (nextUnlockElement) {
            const nextRank = this.getNextRankProgress();
            nextUnlockElement.textContent = nextRank ? nextRank.nextRank : 'Max Rank';
        }
    }

    updateChallengesDisplay() {
        const dailyContainer = document.getElementById('daily-challenges');
        const weeklyContainer = document.getElementById('weekly-challenges');

        if (dailyContainer) {
            dailyContainer.innerHTML = this.userData.challenges.daily.map(challenge => 
                this.createChallengeHTML(challenge)
            ).join('');
        }

        if (weeklyContainer) {
            weeklyContainer.innerHTML = this.userData.challenges.weekly.map(challenge => 
                this.createChallengeHTML(challenge)
            ).join('');
        }
    }

    createChallengeHTML(challenge) {
        const progress = (challenge.progress / challenge.target) * 100;
        const isCompleted = challenge.progress >= challenge.target;
        
        return `
            <div class="challenge-item ${isCompleted ? 'completed' : ''}">
                <div class="challenge-info">
                    <h4>${challenge.title}</h4>
                    <p>${challenge.description}</p>
                    <span class="challenge-points">+${challenge.points} pts</span>
                </div>
                <div class="challenge-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${progress}%"></div>
                    </div>
                    <span class="progress-text">${challenge.progress}/${challenge.target}</span>
                </div>
            </div>
        `;
    }

    updateRankDisplay() {
        const rankElement = document.querySelector('.current-rank');
        if (rankElement) {
            const currentRank = this.calculateRank();
            rankElement.textContent = `${currentRank.badge} ${currentRank.name}`;
        }
    }

    updateAuthUI() {
        const authButton = document.getElementById('auth-button');
        if (authButton) {
            if (this.isAuthenticated && this.currentUser) {
                authButton.textContent = `Logout (${this.currentUser.username})`;
                authButton.onclick = () => this.logoutUser();
            } else {
                authButton.textContent = 'Login with Pi';
                authButton.onclick = () => this.authenticateUser();
            }
        }
    }

    // Animations and Effects
    initializeCosmicBackground() {
        // Initialize cosmic background with p5.js or similar
        const backgroundContainer = document.getElementById('cosmic-background');
        if (!backgroundContainer) return;

        // Create star field
        this.createStarField(backgroundContainer);
        
        // Add aurora effects
        this.addAuroraEffect(backgroundContainer);
    }

    createStarField(container) {
        for (let i = 0; i < 100; i++) {
            const star = document.createElement('div');
            star.className = 'star';
            star.style.left = Math.random() * 100 + '%';
            star.style.top = Math.random() * 100 + '%';
            star.style.animationDelay = Math.random() * 3 + 's';
            container.appendChild(star);
        }
    }

    addAuroraEffect(container) {
        const aurora = document.createElement('div');
        aurora.className = 'aurora';
        container.appendChild(aurora);
    }

    startAnimations() {
        // Start streak ring pulse animation
        this.updateStreakRing();
        
        // Start check-in button pulse
        const checkInBtn = document.getElementById('checkin-btn');
        if (checkInBtn) {
            checkInBtn.classList.add('pulse');
        }
    }

    triggerCheckInAnimation() {
        // Trigger particle burst effect
        this.createParticleBurst();
        
        // Animate streak number
        const streakElement = document.getElementById('current-streak');
        if (streakElement) {
            streakElement.classList.add('number-pop');
            setTimeout(() => streakElement.classList.remove('number-pop'), 500);
        }
    }

    createParticleBurst() {
        const burst = document.createElement('div');
        burst.className = 'particle-burst';
        document.body.appendChild(burst);
        
        setTimeout(() => burst.remove(), 1000);
    }

    // Notifications
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => notification.classList.add('show'), 100);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    // Event Listeners
    setupEventListeners() {
        // Check-in button
        const checkInBtn = document.getElementById('checkin-btn');
        if (checkInBtn) {
            checkInBtn.addEventListener('click', () => this.performCheckIn());
        }

        // Wallet panel
        const walletTrigger = document.getElementById('wallet-trigger');
        const walletPanel = document.getElementById('wallet-panel');
        
        if (walletTrigger && walletPanel) {
            walletTrigger.addEventListener('click', () => {
                walletPanel.classList.toggle('open');
            });
        }

        // Filter buttons (for leaderboard)
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.updateLeaderboard(e.target.dataset.filter);
            });
        });

        // Auth button
        this.updateAuthUI();
    }

    // Leaderboard Updates
    updateLeaderboard(timeframe = 'all-time') {
        const leaderboardData = this.generateLeaderboardData(timeframe);
        const leaderboardList = document.getElementById('leaderboard-list');
        
        if (leaderboardList) {
            leaderboardList.innerHTML = leaderboardData.map(user => 
                this.createLeaderboardRowHTML(user)
            ).join('');
        }
    }

    createLeaderboardRowHTML(user) {
        const isCurrentUser = user.isCurrentUser || false;
        const movementIcon = user.movement > 0 ? '↗️' : user.movement < 0 ? '↘️' : '➡️';
        const movementClass = user.movement > 0 ? 'up' : user.movement < 0 ? 'down' : 'same';
        
        return `
            <div class="leaderboard-row ${isCurrentUser ? 'current-user' : ''}">
                <div class="rank">#${user.position}</div>
                <div class="user-info">
                    <span class="username">${user.username}</span>
                    <span class="badge">${this.getRankBadge(user.rank)}</span>
                </div>
                <div class="stats">
                    <span class="streak">${user.streak} day streak</span>
                    <span class="points">${user.points} pts</span>
                </div>
                <div class="movement ${movementClass}">
                    ${movementIcon} ${Math.abs(user.movement)}
                </div>
            </div>
        `;
    }

    getRankBadge(rankName) {
        const badges = {
            'Rookie': '⭐',
            'Grinder': '🔥',
            'Locked': '🔒',
            'Elite': '💎',
            'Legend': '👑'
        };
        return badges[rankName] || '⭐';
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.lokinApp = new LokinApp();
});

// CSS Animations (injected via JavaScript)
const style = document.createElement('style');
style.textContent = `
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    
    @keyframes number-pop {
        0% { transform: scale(1); }
        50% { transform: scale(1.2); }
        100% { transform: scale(1); }
    }
    
    @keyframes star-twinkle {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 1; }
    }
    
    .star {
        position: absolute;
        width: 2px;
        height: 2px;
        background: white;
        border-radius: 50%;
        animation: star-twinkle 3s infinite;
    }
    
    .aurora {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(45deg, 
            rgba(168, 85, 247, 0.1) 0%, 
            rgba(6, 182, 212, 0.1) 50%, 
            rgba(236, 72, 153, 0.1) 100%);
        animation: aurora-flow 8s ease-in-out infinite;
    }
    
    @keyframes aurora-flow {
        0%, 100% { transform: translateX(-10px) rotate(0deg); opacity: 0.3; }
        50% { transform: translateX(10px) rotate(1deg); opacity: 0.6; }
    }
    
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 16px 24px;
        border-radius: 8px;
        color: white;
        font-weight: 600;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        z-index: 1000;
    }
    
    .notification.show {
        transform: translateX(0);
    }
    
    .notification.success { background: linear-gradient(135deg, #10b981, #059669); }
    .notification.warning { background: linear-gradient(135deg, #f59e0b, #d97706); }
    .notification.error { background: linear-gradient(135deg, #ef4444, #dc2626); }
    .notification.info { background: linear-gradient(135deg, #3b82f6, #2563eb); }
    
    .particle-burst {
        position: fixed;
        top: 50%;
        left: 50%;
        width: 100px;
        height: 100px;
        transform: translate(-50%, -50%);
        background: radial-gradient(circle, rgba(168, 85, 247, 0.8) 0%, transparent 70%);
        border-radius: 50%;
        animation: burst 1s ease-out;
        pointer-events: none;
    }
    
    @keyframes burst {
        0% { transform: translate(-50%, -50%) scale(0); opacity: 1; }
        100% { transform: translate(-50%, -50%) scale(3); opacity: 0; }
    }
`;
document.head.appendChild(style);