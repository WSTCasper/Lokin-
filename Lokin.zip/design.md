# Lokin App Design Style Guide

## Design Philosophy

### Visual Language
**Cosmic Neon Aesthetic**: Deep space meets cyberpunk - a sophisticated blend of cosmic mystique and modern digital interfaces. The design evokes the feeling of being in a high-tech space station, looking out into the cosmos while tracking your progress through the stars.

### Color Palette
**Primary Gradient**: Deep violet to indigo transition
- Base: `#1a0b2e` (Deep Space Violet)
- Mid: `#2d1b69` (Cosmic Indigo) 
- Accent: `#4c1d95` (Stellar Purple)

**Neon Accents**:
- Glowing Cyan: `#06b6d4` (Information, Links)
- Electric Purple: `#a855f7` (Primary Actions)
- Cosmic Pink: `#ec4899` (Secondary Actions)
- Stellar Gold: `#fbbf24` (Achievements, Ranks)

**Text Colors**:
- Primary Text: `#f8fafc` (Starlight White)
- Secondary Text: `#cbd5e1` (Lunar Silver)
- Muted Text: `#64748b` (Space Gray)

### Typography
**Display Font**: "Orbitron" - Futuristic, geometric sans-serif for headings and numbers
**Body Font**: "Inter" - Clean, readable sans-serif for UI text and descriptions
**Accent Font**: "JetBrains Mono" - Monospace for data, stats, and technical info

## Visual Effects

### Used Libraries & Effects
1. **Anime.js**: Smooth streak counter animations, button pulse effects, progress bar fills
2. **Pixi.js**: Cosmic particle background, glowing ring animations, floating stars
3. **Shader-park**: Dynamic gradient backgrounds, aurora-like flowing effects
4. **Typed.js**: Typewriter effect for motivational messages and achievement notifications
5. **Splitting.js**: Character-by-character text animations for dramatic reveals
6. **p5.js**: Interactive star field backgrounds, constellation patterns
7. **ECharts.js**: Progress visualization with cosmic-themed styling

### Animation Patterns
**Streak Ring**: Glowing circular progress indicator with pulsing animation
- Outer glow with CSS box-shadow: `0 0 30px rgba(168, 85, 247, 0.5)`
- Inner ring with animated stroke-dasharray for progress
- Particle effects on completion using Pixi.js

**Daily Check-in Button**: 
- Subtle pulse animation using Anime.js scale transforms
- Glow effect that intensifies on hover/touch
- Ripple effect on tap using CSS animations

**Challenge Progress Bars**:
- Animated fill with cosmic gradient
- Sparkle particles on completion
- Smooth easing curves for natural movement

### Header Effects
**Cosmic Background**: Dynamic shader-generated space scene
- Slowly moving star field
- Subtle nebula clouds with color shifting
- Depth parallax layers for immersion

**Navigation Transitions**:
- Smooth slide animations between screens
- Fade effects with cosmic particle trails
- Maintains visual continuity across pages

## Component Styling

### Cards & Containers
- **Background**: Semi-transparent dark overlays with subtle blur
- **Border**: 1px solid rgba(168, 85, 247, 0.2)
- **Shadow**: `0 8px 32px rgba(0, 0, 0, 0.3)`
- **Radius**: 16px for modern, friendly appearance

### Interactive Elements
**Buttons**:
- Primary: Electric purple gradient with white text
- Secondary: Transparent with glowing border
- Disabled: Muted colors with reduced opacity

**Form Elements**:
- Input fields with cosmic glow focus states
- Dropdowns with space-themed styling
- Toggle switches resembling star gates

### Data Visualization
**Leaderboard**:
- Alternating row colors with subtle cosmic gradients
- Current user highlighted with golden glow
- Rank badges with metallic space-age styling

**Progress Indicators**:
- Circular progress with animated stroke
- Linear bars with particle trail effects
- Achievement badges with unlock animations

## Layout Principles

### Grid System
- 4px base unit for consistent spacing
- 16px, 24px, 32px, 48px spacing scale
- Responsive breakpoints: 320px, 768px, 1024px, 1440px

### Hierarchy
- Large, bold numbers for streak counters
- Clear visual separation between sections
- Strategic use of neon colors to guide attention

### Mobile-First Design
- Touch-friendly 44px minimum tap targets
- Optimized for thumb navigation
- Swipe gestures for secondary actions

## Accessibility Considerations

### Contrast Ratios
- All text meets WCAG AA standards (4.5:1 minimum)
- Neon elements tested against dark backgrounds
- Alternative text for all decorative elements

### Motion Sensitivity
- Reduced motion options for users with vestibular disorders
- Essential information never conveyed through animation alone
- Pause controls for continuous animations

### Color Independence
- Information never conveyed through color alone
- Icons and text labels supplement color coding
- High contrast mode compatibility

This design system creates an immersive cosmic experience while maintaining usability and accessibility standards. The combination of deep space aesthetics with modern UI patterns will make users feel like they're navigating through a high-tech space station while tracking their personal growth journey.